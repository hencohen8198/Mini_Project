package mines;

import java.io.IOException;
import java.util.Random;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class MinesFX extends Application {

	private String red = "-fx-text-fill: red";				//strings of diffrent colors to fill the numbers
	private String blue = "-fx-text-fill: #0000ff";			//*
	private String redBrick = "-fx-text-fill: #9400d3";		//*
	private String Green = "-fx-text-fill: #228b22";		//*
	private String deepBlue = "-fx-text-fill: #000080";		//*
	private String orange = "-fx-text-fill: #ffa500";		//*
	private String purple = "-fx-text-fill: #800080";		//*
	private String pink = "-fx-text-fill: #dda0dd";			//read README in the project

	private HBox hbox = null;								//the hbox of the scene
	private int width = 10;									//a default values of the mineGrid
	private int heigth = 10;								//*
	private int numMines = 5;								//*
	private Mines m = new Mines(heigth, width, 5);			//*
	private MyController controller = null;
	private Button[][] b;
	private GridPane g = new GridPane();
	private boolean gameOver = false;
	private Image image = new Image(getClass().getResourceAsStream("a.png"), 15, 15, false, false); //image of the mine, read README
	private Stage stage;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {

		try {
			FXMLLoader loader = new FXMLLoader();							//loading the scene and controller
			loader.setLocation(getClass().getResource("mineFX.fxml"));
			this.hbox = loader.load();
			controller = loader.getController();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Scene s = new Scene(hbox);											//creating the scene
		primaryStage.setTitle("The Amazing Mines Sweeper");
		primaryStage.setScene(s);
		primaryStage.show();							
		stage = primaryStage;												//saving the stage for size editing
		setGrid(g);															//creating a grid for default play
		stage.setWidth(heigth * 40 + 190);
		stage.setHeight(Math.max(width * 40 + 70, 181));
		controller.stack.getChildren().add(g);
		controller.reset.setOnAction(new EventHandler<ActionEvent>() {		//when reset is clicked, create an eventhandler

			@Override
			public void handle(ActionEvent event) {
				gameOver = false;											//the gameover flag is false
				try {
					heigth = !controller.heigthT.getText().equals("") ? Integer.parseInt(controller.widthT.getText()) //if text is empty, then its 0
							: 0;
					width = !controller.heigthT.getText().equals("") ? Integer.parseInt(controller.heigthT.getText())
							: 0;
					numMines = !controller.heigthT.getText().equals("") ? Integer.parseInt(controller.minesT.getText())
							: 0;
				} catch (Exception e) {										//catching exception for invalid input
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Invalid Input");
					alert.setHeaderText(null);
					alert.setContentText("Input that was typed is invalid, please try again");
					alert.show();
					return;
				}
				if ((heigth <= 0 || width <= 0 || numMines < 0 || numMines > heigth * width)) {	//handling invalid input 
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Invalid Input");
					alert.setHeaderText(null);
					alert.setContentText("Input that was typed is invalid, please try again");
					alert.show();
					return;
				}
				controller.stack.getChildren().remove(g);										//if input is valid, remove grid and create a new one
				g = new GridPane();
				g.setPadding(new Insets(40, 40, 40, 40));
				setGrid(g);
				controller.stack.getChildren().add(g);
				stage.setWidth(heigth * 40 + 190);
				stage.setHeight(Math.max(width * 40 + 70, 181));
			}
		});

	}

	private void setGrid(GridPane g) {													//setting the new grid here
		g.setPadding(new Insets(40, 40, 40, 40));
		g.setAlignment(Pos.CENTER);
		b = new Button[heigth][width];
		m = new Mines(heigth, width, numMines);
		randMines();																	//adding random mines to the grid
		for (int i = 0; i < heigth; i++) {												//creating buttons in the grid
			for (int j = 0; j < width; j++) {
				b[i][j] = new Button(m.get(i, j));
				b[i][j].setPrefSize(40.0, 40.0);
				b[i][j].setMinSize(40.0, 40.0);
				b[i][j].setMaxSize(40.0, 40.0);
				b[i][j].setFont(new Font("Ariel",20));
				g.add(b[i][j], i, j);
				b[i][j].setOnMouseClicked(new ClickedButton(i, j));						//creating eventhandlers for each button
			}
		}
		g.setMinSize((double) (40 * (heigth) + 20), (double) (40 * (width) + 20));
		g.setPrefSize(Double.MAX_VALUE, Double.MAX_VALUE);
	}

	public class ClickedButton implements EventHandler<MouseEvent> {					//when a button is clicked:

		private int x;
		private int y;

		public ClickedButton(int x, int y) {											//constractor with the coordinates of the button
			this.x = x;
			this.y = y;
		}

		@Override
		public void handle(MouseEvent event) {
			if (!gameOver) {															//if the game havent ended:
				if (event.getButton() == MouseButton.PRIMARY && !b[x][y].getText().equals("F")) {	//if its the left mouse button and the button isnt flaged:
					if (!m.open(x, y)) {												//open the position
						m.setShowAll(true);												//if we hit a mine: showall 
						for (int i = 0; i < heigth; i++)
							for (int j = 0; j < width; j++) {
								if (m.get(i, j).equals("X"))							//if there is a mine in the button, then put an image of a mine there:
									b[i][j].setGraphic(new ImageView(image));			//read README
							}
						Alert alert = new Alert(AlertType.INFORMATION);					//create an alert message for the player
						alert.setTitle("Lose");
						alert.setHeaderText(null);
						alert.setContentText("Sorry, You Lost");
						alert.show();
						gameOver = true;												//gameover is true;
					}

				}
				if (event.getButton() == MouseButton.SECONDARY)							//if right mouse button clicked:
					m.toggleFlag(x, y);													//toggle flag there
				for (int i = 0; i < heigth; i++)										//after the click, update the screen
					for (int j = 0; j < width; j++)
						b[i][j].setText(m.get(i, j));
				for (int i = 0; i < heigth; i++)
					for (int j = 0; j < width; j++)
						if (!m.get(i, j).equals(".") || !m.get(i, j).equals(" ") || !m.get(i, j).equals("X")) //if its a numbered tile, color it
							setColor(b[i][j]);																	//read README
				if (m.isDone()) {														//if game is done create an alert for the player
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Won");
					alert.setHeaderText(null);
					alert.setContentText("Congratulations!, You Won!");
					alert.show();
					gameOver = true;													//game over is true
				}
			}
		}
	}

	private void setColor(Button button) {									//a method to color each number acording to its value
		if (button.getText().equals("1"))
			button.setStyle(red);
		if (button.getText().equals("2"))
			button.setStyle(blue);
		if (button.getText().equals("3"))
			button.setStyle(redBrick);
		if (button.getText().equals("4"))
			button.setStyle(Green);
		if (button.getText().equals("5"))
			button.setStyle(deepBlue);
		if (button.getText().equals("6"))
			button.setStyle(orange);
		if (button.getText().equals("7"))
			button.setStyle(purple);
		if (button.getText().equals("8"))
			button.setStyle(pink);
		return;
	}

	private void randMines() {												//randomize the grid with mines
		int count = 0;
		Random randW = new Random();
		Random randH = new Random();
		while (count != numMines) {
			if (m.addMine(randH.nextInt(heigth), randW.nextInt(width))) {	//if there isnt a mine there, add a new one
				count++;
			}
		}
	}

}
