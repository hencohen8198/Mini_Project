package mines;

import java.util.ArrayList;
import java.util.List;

public class Mines {

	private int height;
	private int width;
	@SuppressWarnings("unused")
	private int numMines;
	private Posi[][] arr;
	private boolean fl;

	public class Posi {											//inner class for a single position in mines

		private int value;										//value of a position
		private char flag = '.';								//the char displayed
		private List<Posi> neib;								//a list of the neigbours
		private int x;											//its x,y values
		private int y;
		private int count;										//abount of mines in the neigbours

		private Posi(int x, int y, int value) {					//constractor that gets coordinates, and value
			this.value = value;
			this.x = x;
			this.y = y;
			neib = new ArrayList<Posi>();						//creating an empty list for now
			count = 0;
		}

		private int getVal() {									//setters and getters
			return value;
		}

		private char getFlag() {
			return flag;
		}

		private void setVal(int v) {
			this.value = v;
		}

		private void setF(char c) {
			this.flag = c;
		}

		private List<Posi> getN() {
			return neib;
		}

		private void addN(Posi p) {								//adding another posi to the neigbour list
			neib.add(p);
		}

		private void addM() {									//adding 1 to the amount of mines in the neigbours
			count++;
		}

		private int getM() {
			return count;
		}
	}

	public Mines(int height, int width, int numMines) {			//constractor for Mines
		this.height = height;
		this.width = width;
		this.numMines = numMines;
		arr = new Posi[height][width];							//creating a grid of posi objects
		fl = false;												//showall is false								
		for (int i = 0; i < height; i++) {						//creating posi objects for each position in the mines grid
			for (int j = 0; j < width; j++) {
				arr[i][j] = new Posi(i, j, 0);					//creating a posi with the value 0, meaning its empty
			}
		}
		for (int i = 0; i < height; i++) {						//here we have a system to determine which other posi we add to the neigbour of a single position
			for (int j = 0; j < width; j++) {
				if (i < height - 1) {
					arr[i][j].addN(arr[i + 1][j]);
					if (j < width - 1) {
						arr[i][j].addN(arr[i + 1][j + 1]);
					}
					if (j > 0)
						arr[i][j].addN(arr[i + 1][j - 1]);
				}
				if (i > 0) {
					arr[i][j].addN(arr[i - 1][j]);
					if (j < width - 1)
						arr[i][j].addN(arr[i - 1][j + 1]);
					if (j > 0)
						arr[i][j].addN(arr[i - 1][j - 1]);
				}
				if (j < width - 1) {
					arr[i][j].addN(arr[i][j + 1]);
				}
				if (j > 0) {
					arr[i][j].addN(arr[i][j - 1]);
				}
			}
		}
	}

	public boolean addMine(int i, int j) {						//adding a mine to a position
		if (this.arr[i][j].getVal() == 1)						//if the value is 1, meaning there is already a mine there, return false
			return false;
		else {													//else, set the value to 1
			this.arr[i][j].setVal(1);
			for (Posi posi : this.arr[i][j].getN()) {			//then we update the neigbouring posi that a mine has been added
				posi.addM();									//we add a mine to the counter for each of them
			}
			return true;										//exiting with true
		}
	}

	public boolean open(int i, int j) {							//opening a position

		if (arr[i][j].getVal() == 1)							//if we hit a mine, return false without opening it
			return false;
		arr[i][j].setVal(-1);									//else, set the value of the posi to -1, meaning it has been opened
		if (arr[i][j].getM() == 0)								//then, if there are no mines around the opened posi, open all of its neigbours
			for (Posi p : arr[i][j].getN())
				if (p.getVal() == 0)
					open(p.x, p.y);
		return true;											//at the end, return true;
	}

	public void toggleFlag(int x, int y) {					
		if (this.arr[x][y].getVal() != -1) {		
			if(this.arr[x][y].getFlag() != 'F')
				this.arr[x][y].setF('F');						//if the posi isnt opened, and the value is '.', switch it to 'F'
		else {
			this.arr[x][y].setF('.');							//if value is 'F', switch it to '.'				
			}
		}
	}
	public boolean isDone() {
		for (Posi[] posis : arr) {
			for (Posi posi : posis) {
				if (posi.getVal() == 0)							//if any posi in the grid hasent been open and not a mine, return false
					return false;
			}
		}
		return true;											//else, everything a or a mine or have been opened, then return true;
	}

	public String get(int i, int j) {
		if (!fl) {												//if showall flag is false:
			if (arr[i][j].getVal() != -1)
				return String.format("%c", arr[i][j].getFlag());//if its not a opened, return the flag in it
			else {
				if (arr[i][j].getM() == 0)						//if its opened, and there are no mines around it, return ' '
					return " ";
				return (new Integer(arr[i][j].getM())).toString();//else, return the number of mines around it
			}
		} else {												//if showall is true:
			if (arr[i][j].getVal() == 1)
				return "X";
			if (arr[i][j].getM() == 0)
				return " ";
			return (new Integer(arr[i][j].getM())).toString();
		}
	}

	public void setShowAll(boolean showAll) {				//setting showall
		fl = showAll;
	}

	public String toString() {								//a simple to string
		String s = new String();
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				s += get(i, j);
			}
			s += "\n";
		}
		return s;
	}
}
