package mines;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;

public class MyController {

	@FXML
	protected Button reset;								//no need of explaining here

	@FXML
	protected TextField widthT;

	@FXML
	protected TextField heigthT;

	@FXML
	protected TextField minesT;

    @FXML
    protected StackPane stack;

    @FXML
    void EnteredHeigth(InputMethodEvent event) {

    }

    @FXML
    void EnteredMines(InputMethodEvent event) {

    }

    @FXML
    void EnteredWidth(InputMethodEvent event) {

    }

    @FXML
    void PressedReset(MouseEvent event) {

    }

}
